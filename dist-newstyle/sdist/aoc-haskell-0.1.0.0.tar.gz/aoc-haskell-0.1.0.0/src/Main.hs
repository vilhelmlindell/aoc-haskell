module Main (
    main,
) where

import Year2020
import Year2023.Day

type Year = (Int, Int) -> String -> String
getYear :: Int -> Year
getYear year = case year of
    2020 -> Year2020.Day.getAnswerForDay
    2023 -> Year2020.Day.getAnswerForDay
    _ -> error "No such year"

main :: IO ()
main = do
    putStrLn "Enter the year number (2015-2023)"
    yearNumberStr <- getLine
    let yearNumber = read yearNumberStr :: Int

    putStrLn "Enter the day number (1-24):"
    dayNumberStr <- getLine
    let dayNumber = read dayNumberStr :: Int

    putStrLn "Enter the part number (1-2):"
    partNumberStr <- getLine
    let partNumber = read partNumberStr :: Int

    let inputPath = getInputFilePath dayNumber

    contents <- readFile inputPath
    let answer = getAnswerForDay (dayNumber, partNumber) contents
    putStrLn answer
