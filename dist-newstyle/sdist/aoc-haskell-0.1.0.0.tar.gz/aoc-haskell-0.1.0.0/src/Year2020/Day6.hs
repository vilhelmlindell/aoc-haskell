module Year2020.Day6
( getAnswerPart1 
, getAnswerPart2
) where

getAnswerPart1 :: String -> String
getAnswerPart1 input = ""

getAnswerPart2 :: String -> String
getAnswerPart2 input = ""
