module Year2023.Day (
    getAnswerForDay,
    getInputFilePath,
) where

import Year2023.Day1 as Day1

getAnswerForDay :: (Int, Int) -> String -> String
getAnswerForDay (dayNumber, partNumber) input = case (dayNumber, partNumber) of
    (1, 1) -> Day1.getAnswerPart1 input
    _ -> "Day not implemented yet"

getInputFilePath :: Int -> FilePath
getInputFilePath dayNumber = "input/Year2023/Day" ++ show dayNumber ++ ".txt"
