module Year2023.Day1 (
    getAnswerPart1,
    getAnswerPart2,
) where

getAnswerPart1 :: String -> String
getAnswerPart1 input = undefined

getAnswerPart2 :: String -> String
getAnswerPart2 input = undefined
